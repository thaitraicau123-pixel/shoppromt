@echo off
chcp 65001 >nul
title Cài Đặt Tự Động OpenJarvis AI - Bùi Thái AI Studio
color 0A

echo ===============================================================================
echo     🤖 BÙI THÁI AI STUDIO - TRÌNH CÀI ĐẶT TỰ ĐỘNG 1-CHẠM OPENJARVIS
echo     Local-First Personal AI (Stanford University) trên Windows
echo ===============================================================================
echo.
echo [1/3] Đang kiểm tra môi trường Windows PowerShell...
echo [2/3] Bắt đầu tự động tải uv, tạo môi trường Python venv, nạp Ollama và Model...
echo       Quá trình này mất khoảng 2-3 phút tùy tốc độ mạng của bạn.
echo.
echo -------------------------------------------------------------------------------

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "irm https://open-jarvis.github.io/OpenJarvis/install.ps1 | iex"

echo.
echo -------------------------------------------------------------------------------
if %ERRORLEVEL% EQU 0 (
    echo [3/3] ✅ CÀI ĐẶT THÀNH CÔNG RỰC RỠ!
    echo.
    echo 👉 Để mở Giao diện Trực quan trên Trình duyệt Web: Nhấp đúp vào file 'Chay_OpenJarvis_Giao_Dien_Web.bat'
    echo 👉 Để chat trên cửa sổ dòng lệnh: Nhấp đúp vào file 'Chay_OpenJarvis_Terminal.bat'
) else (
    echo [!] Quá trình cài đặt gặp gián đoạn. Vui lòng kiểm tra kết nối mạng và thử lại.
)
echo.
echo Nhấn phím bất kỳ để đóng cửa sổ này...
pause >nul
