@echo off
chcp 65001 >nul
title Khởi Động OpenJarvis Terminal Chat - Bùi Thái Studio
color 0E

echo ===============================================================================
echo     💬 KHỞI ĐỘNG TRÒ CHUYỆN OPENJARVIS TERMINAL CHAT (OFFLINE 100%)
echo ===============================================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "jarvis"

if %ERRORLEVEL% NEQ 0 (
    echo [!] Đang thử khởi động qua uv run...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "uv run jarvis"
)
pause
