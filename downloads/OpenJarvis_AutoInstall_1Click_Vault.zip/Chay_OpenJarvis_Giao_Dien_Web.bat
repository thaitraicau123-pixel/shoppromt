@echo off
chcp 65001 >nul
title Khởi Động Giao Diện Web OpenJarvis GUI - Bùi Thái Studio
color 0B

echo ===============================================================================
echo     🌐 KHỞI ĐỘNG GIAO DIỆN WEB OPENJARVIS LOCAL AI TRÊN TRÌNH DUYỆT
echo ===============================================================================
echo.
echo Đang kích hoạt máy chủ cục bộ và tự động mở trình duyệt...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "jarvis gui"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [!] Nếu lệnh 'jarvis' chưa nhận diện được trong PATH, đang thử khởi động qua môi trường uv...
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "uv run jarvis gui"
)
pause
